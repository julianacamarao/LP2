﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ValorA;
        double ValorB;
        double ValorC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtA.Text, out ValorA) || (ValorA <= 0))
            {
                MessageBox.Show("Valor Inválido");
                e.Cancel = true;
            }
        }

        private void txtB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtB.Text, out ValorB) || (ValorB <= 0))
            {
                MessageBox.Show("Valor Inválido");
                e.Cancel = true;
            }
        }

        private void txtC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtC.Text, out ValorC) || (ValorC <= 0))
            {
                MessageBox.Show("Valor Inválido");
                e.Cancel = true;
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ValorA < ValorB + ValorC) &&
                      (ValorA > Math.Abs(ValorB - ValorC)) &&
                      (ValorB < ValorA + ValorC) &&
                      (ValorB > Math.Abs(ValorA - ValorC)) &&
                      (ValorC < ValorA + ValorB) &&
                      (ValorC > Math.Abs(ValorA - ValorB)))
            {
                if (ValorA == ValorB && ValorB == ValorC && ValorC == ValorA)
                    MessageBox.Show("Triângulo Equilatero");
                else if (ValorA == ValorB || ValorB == ValorC || ValorC == ValorA)
                    MessageBox.Show("Triângulo Isósceles");
                else
                    MessageBox.Show("Triângulo Escaleno");

            }
            else
                MessageBox.Show("Não é triângulo");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
