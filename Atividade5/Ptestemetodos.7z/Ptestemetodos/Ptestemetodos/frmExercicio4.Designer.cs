﻿namespace Ptestemetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContarNum = new System.Windows.Forms.Button();
            this.btnEspaço = new System.Windows.Forms.Button();
            this.btnContarLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(91, 39);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(570, 290);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContarNum
            // 
            this.btnContarNum.Location = new System.Drawing.Point(91, 358);
            this.btnContarNum.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnContarNum.Name = "btnContarNum";
            this.btnContarNum.Size = new System.Drawing.Size(151, 122);
            this.btnContarNum.TabIndex = 1;
            this.btnContarNum.Text = "Contar Número";
            this.btnContarNum.UseVisualStyleBackColor = true;
            this.btnContarNum.Click += new System.EventHandler(this.btnContarNum_Click);
            // 
            // btnEspaço
            // 
            this.btnEspaço.Location = new System.Drawing.Point(302, 358);
            this.btnEspaço.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnEspaço.Name = "btnEspaço";
            this.btnEspaço.Size = new System.Drawing.Size(151, 122);
            this.btnEspaço.TabIndex = 2;
            this.btnEspaço.Text = "Primeiro Espaço em Branco";
            this.btnEspaço.UseVisualStyleBackColor = true;
            this.btnEspaço.Click += new System.EventHandler(this.btnEspaço_Click);
            // 
            // btnContarLetras
            // 
            this.btnContarLetras.Location = new System.Drawing.Point(512, 358);
            this.btnContarLetras.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnContarLetras.Name = "btnContarLetras";
            this.btnContarLetras.Size = new System.Drawing.Size(151, 122);
            this.btnContarLetras.TabIndex = 3;
            this.btnContarLetras.Text = "Contar Letras";
            this.btnContarLetras.UseVisualStyleBackColor = true;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 703);
            this.Controls.Add(this.btnContarLetras);
            this.Controls.Add(this.btnEspaço);
            this.Controls.Add(this.btnContarNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContarNum;
        private System.Windows.Forms.Button btnEspaço;
        private System.Windows.Forms.Button btnContarLetras;
    }
}